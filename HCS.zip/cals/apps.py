from django.apps import AppConfig


class CalsConfig(AppConfig):
    name = 'cals'
